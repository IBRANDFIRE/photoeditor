import React, { useState } from "react";
import { Adjustments, DEFAULT_ADJUSTMENTS } from "../types";
import { Sun, Palette, Sparkles, SlidersHorizontal, RotateCcw } from "lucide-react";

interface AdjustmentsPanelProps {
  adjustments: Adjustments;
  onChange: (adj: Adjustments) => void;
}

type GroupKey = "light" | "color" | "presence" | "detail";

interface SliderConfig {
  key: keyof Adjustments;
  label: string;
  min: number;
  max: number;
  step?: number;
  format?: (val: number) => string;
}

export const AdjustmentsPanel: React.FC<AdjustmentsPanelProps> = ({
  adjustments,
  onChange,
}) => {
  const [activeGroup, setActiveGroup] = useState<GroupKey>("light");

  const updateField = (key: keyof Adjustments, val: number) => {
    onChange({
      ...adjustments,
      [key]: val,
    });
  };

  const resetField = (key: keyof Adjustments) => {
    updateField(key, DEFAULT_ADJUSTMENTS[key]);
  };

  const resetAll = () => {
    onChange(DEFAULT_ADJUSTMENTS);
  };

  const groups: Record<GroupKey, { title: string; icon: any; sliders: SliderConfig[] }> = {
    light: {
      title: "Light & Exposure",
      icon: Sun,
      sliders: [
        {
          key: "exposure",
          label: "Exposure",
          min: -3,
          max: 3,
          step: 0.05,
          format: (v) => (v > 0 ? `+${v.toFixed(2)} EV` : `${v.toFixed(2)} EV`),
        },
        {
          key: "contrast",
          label: "Contrast",
          min: -100,
          max: 100,
          format: (v) => (v > 0 ? `+${v}` : `${v}`),
        },
        {
          key: "highlights",
          label: "Highlights",
          min: -100,
          max: 100,
          format: (v) => (v > 0 ? `+${v}` : `${v}`),
        },
        {
          key: "shadows",
          label: "Shadows",
          min: -100,
          max: 100,
          format: (v) => (v > 0 ? `+${v}` : `${v}`),
        },
        {
          key: "whites",
          label: "Whites",
          min: -100,
          max: 100,
          format: (v) => (v > 0 ? `+${v}` : `${v}`),
        },
        {
          key: "blacks",
          label: "Blacks",
          min: -100,
          max: 100,
          format: (v) => (v > 0 ? `+${v}` : `${v}`),
        },
      ],
    },
    color: {
      title: "White Balance & Color",
      icon: Palette,
      sliders: [
        {
          key: "temperature",
          label: "Temperature (Cool - Warm)",
          min: -100,
          max: 100,
          format: (v) => (v > 0 ? `+${v} Warm` : v < 0 ? `${v} Cool` : "0"),
        },
        {
          key: "tint",
          label: "Tint (Green - Magenta)",
          min: -100,
          max: 100,
          format: (v) => (v > 0 ? `+${v} Mag` : v < 0 ? `${v} Grn` : "0"),
        },
        {
          key: "vibrance",
          label: "Vibrance (Skin-Safe)",
          min: -100,
          max: 100,
          format: (v) => (v > 0 ? `+${v}` : `${v}`),
        },
        {
          key: "saturation",
          label: "Saturation",
          min: -100,
          max: 100,
          format: (v) => (v > 0 ? `+${v}` : `${v}`),
        },
      ],
    },
    presence: {
      title: "Texture & Presence",
      icon: Sparkles,
      sliders: [
        {
          key: "clarity",
          label: "Clarity (Midtone Contrast)",
          min: -100,
          max: 100,
          format: (v) => (v > 0 ? `+${v}` : `${v}`),
        },
        {
          key: "texture",
          label: "Texture (Fine Details)",
          min: -100,
          max: 100,
          format: (v) => (v > 0 ? `+${v}` : `${v}`),
        },
        {
          key: "dehaze",
          label: "Dehaze (Atmospheric)",
          min: -100,
          max: 100,
          format: (v) => (v > 0 ? `+${v}` : `${v}`),
        },
        {
          key: "vignette",
          label: "Vignette",
          min: -100,
          max: 100,
          format: (v) => (v > 0 ? `+${v} Dark` : v < 0 ? `${v} Light` : "0"),
        },
      ],
    },
    detail: {
      title: "Details & Grain",
      icon: SlidersHorizontal,
      sliders: [
        {
          key: "sharpen",
          label: "Sharpening",
          min: 0,
          max: 100,
          format: (v) => `${v}%`,
        },
        {
          key: "grain",
          label: "Film Grain",
          min: 0,
          max: 100,
          format: (v) => `${v}%`,
        },
      ],
    },
  };

  const currentGroup = groups[activeGroup];

  return (
    <div className="space-y-4">
      {/* Group Navigation Chips */}
      <div className="flex items-center justify-between">
        <div className="flex bg-zinc-900 p-1 rounded-xl border border-zinc-800 text-xs overflow-x-auto scrollbar-none">
          {(Object.keys(groups) as GroupKey[]).map((k) => {
            const grp = groups[k];
            const Icon = grp.icon;
            const isSelected = activeGroup === k;
            return (
              <button
                key={k}
                type="button"
                onClick={() => setActiveGroup(k)}
                className={`flex items-center gap-1.5 px-3 py-1.5 font-semibold rounded-lg transition whitespace-nowrap ${
                  isSelected
                    ? "bg-zinc-800 text-white shadow-xs"
                    : "text-zinc-400 hover:text-zinc-200"
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{k.charAt(0).toUpperCase() + k.slice(1)}</span>
              </button>
            );
          })}
        </div>

        <button
          type="button"
          onClick={resetAll}
          title="Reset all adjustments"
          className="flex items-center gap-1 text-xs text-zinc-400 hover:text-white px-2.5 py-1.5 rounded-lg bg-zinc-900 border border-zinc-800 transition"
        >
          <RotateCcw className="w-3 h-3" />
          <span>Reset</span>
        </button>
      </div>

      {/* Sliders Container */}
      <div className="bg-zinc-900/90 border border-zinc-800/80 rounded-2xl p-4 space-y-4 shadow-sm">
        <div className="text-xs font-semibold uppercase tracking-wider text-zinc-400 border-b border-zinc-800/60 pb-2">
          {currentGroup.title}
        </div>

        <div className="grid grid-cols-1 gap-3.5">
          {currentGroup.sliders.map((s) => {
            const val = adjustments[s.key];
            const formatted = s.format ? s.format(val) : val.toString();
            const isModified = val !== DEFAULT_ADJUSTMENTS[s.key];

            return (
              <div key={s.key} className="space-y-1">
                <div className="flex items-center justify-between text-xs">
                  <span className="text-zinc-300 font-medium">{s.label}</span>
                  <button
                    type="button"
                    onClick={() => resetField(s.key)}
                    title="Tap to reset"
                    className={`font-mono transition ${
                      isModified
                        ? "text-sky-400 font-semibold hover:text-sky-300"
                        : "text-zinc-500 hover:text-zinc-300"
                    }`}
                  >
                    {formatted}
                  </button>
                </div>
                <input
                  type="range"
                  min={s.min}
                  max={s.max}
                  step={s.step || 1}
                  value={val}
                  onChange={(e) =>
                    updateField(s.key, parseFloat(e.target.value))
                  }
                  className="w-full h-2 bg-zinc-800 rounded-lg appearance-none cursor-pointer accent-sky-400"
                />
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
