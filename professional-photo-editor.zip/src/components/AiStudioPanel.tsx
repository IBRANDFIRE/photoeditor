import React, { useState } from "react";
import {
  AiMaskState,
  TargetMaskLayer,
  Adjustments,
  VirtualLight,
  SkyAtmosphere,
  SkyPreset,
} from "../types";
import {
  Wand2,
  ScanEye,
  Scissors,
  Layers,
  Sparkles,
  Loader2,
  CheckCircle2,
  RotateCcw,
  Palette,
  Eye,
  EyeOff,
  SunMedium,
  CloudSun,
  Lightbulb,
  Crosshair,
  Sliders,
} from "lucide-react";

interface AiStudioPanelProps {
  currentImageDataUrl: string;
  aiMaskState: AiMaskState;
  showMaskOverlay: boolean;
  virtualLight: VirtualLight;
  skyAtmosphere: SkyAtmosphere;
  onToggleMaskOverlay: () => void;
  onDetectSubject: () => Promise<void>;
  onSmartEnhance: () => Promise<string | undefined>;
  onUpdateAiMaskState: (state: Partial<AiMaskState>) => void;
  onApplySubjectPreset: (type: "pop-subject" | "dim-background") => void;
  onResetMask: () => void;
  onUpdateVirtualLight: (light: Partial<VirtualLight>) => void;
  onUpdateSkyAtmosphere: (sky: Partial<SkyAtmosphere>) => void;
  isAiLoading: boolean;
  aiStatusMessage: string;
}

const BACKDROP_COLORS = [
  { name: "Pure White", value: "#ffffff" },
  { name: "Onyx Black", value: "#0a0a0c" },
  { name: "Studio Grey", value: "#4b5563" },
  { name: "Warm Linen", value: "#f5f0ea" },
  { name: "Deep Navy", value: "#0f172a" },
  { name: "Cyber Teal", value: "#0d9488" },
];

export const AiStudioPanel: React.FC<AiStudioPanelProps> = ({
  aiMaskState,
  showMaskOverlay,
  virtualLight,
  skyAtmosphere,
  onToggleMaskOverlay,
  onDetectSubject,
  onSmartEnhance,
  onUpdateAiMaskState,
  onApplySubjectPreset,
  onResetMask,
  onUpdateVirtualLight,
  onUpdateSkyAtmosphere,
  isAiLoading,
  aiStatusMessage,
}) => {
  const [enhancementSummary, setEnhancementSummary] = useState<string | null>(null);

  const handleEnhanceClick = async () => {
    const summary = await onSmartEnhance();
    if (summary) {
      setEnhancementSummary(summary);
    }
  };

  const LIGHT_PRESETS = [
    { name: "Key Left", x: 0.25, y: 0.25, warmth: 20, color: "#ffc87a" },
    { name: "Key Right", x: 0.75, y: 0.25, warmth: 20, color: "#ffc87a" },
    { name: "Rembrandt", x: 0.35, y: 0.2, warmth: 15, color: "#ffe0b2" },
    { name: "Ring Light", x: 0.5, y: 0.45, warmth: 5, color: "#ffffff" },
    { name: "Rim Back", x: 0.85, y: 0.4, warmth: 30, color: "#ffb74d" },
    { name: "Cyber Cyan", x: 0.2, y: 0.5, warmth: -35, color: "#38bdf8" },
  ];

  const SKY_PRESETS: { id: SkyPreset; name: string; desc: string; colors: string }[] = [
    { id: "none", name: "Original", desc: "Keep natural sky", colors: "from-zinc-700 to-zinc-800" },
    { id: "golden", name: "Golden Hour", desc: "Warm rich amber glow", colors: "from-amber-500 to-orange-600" },
    { id: "sunset", name: "Sunset Blaze", desc: "Vibrant violet & crimson", colors: "from-fuchsia-600 to-amber-500" },
    { id: "azure", name: "Azure Sky", desc: "Deep cinematic blue", colors: "from-blue-600 to-cyan-400" },
    { id: "starry", name: "Starry Night", desc: "Deep indigo twilight", colors: "from-indigo-950 via-slate-900 to-purple-900" },
    { id: "dusk", name: "Moody Dusk", desc: "Muted atmospheric twilight", colors: "from-purple-800 to-rose-700" },
  ];

  return (
    <div className="space-y-4">
      {/* 1. Smart Image Enhancement Section */}
      <div className="bg-zinc-900/90 border border-zinc-800/80 rounded-2xl p-4 space-y-3 shadow-sm">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-xl bg-sky-500/10 border border-sky-500/20 flex items-center justify-center text-sky-400">
              <Wand2 className="w-4 h-4" />
            </div>
            <div>
              <span className="text-xs font-semibold text-zinc-100">
                Smart Image Enhancement
              </span>
              <p className="text-[11px] text-zinc-400">
                AI visual diagnostic & auto-grading
              </p>
            </div>
          </div>
        </div>

        <button
          type="button"
          onClick={handleEnhanceClick}
          disabled={isAiLoading}
          className="w-full flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl bg-gradient-to-r from-sky-500 to-indigo-600 hover:from-sky-400 hover:to-indigo-500 text-white font-medium text-xs shadow-md transition disabled:opacity-50 disabled:pointer-events-none"
        >
          {isAiLoading ? (
            <>
              <Loader2 className="w-4 h-4 animate-spin" />
              <span>{aiStatusMessage || "Analyzing..."}</span>
            </>
          ) : (
            <>
              <Sparkles className="w-4 h-4" />
              <span>AI Auto-Enhance & Tone Balance</span>
            </>
          )}
        </button>

        {enhancementSummary && (
          <div className="p-3 bg-zinc-950/80 border border-zinc-800 rounded-xl text-xs space-y-1.5 animate-fadeIn">
            <div className="flex items-center gap-1.5 text-emerald-400 font-semibold text-[11px]">
              <CheckCircle2 className="w-3.5 h-3.5" />
              <span>AI Diagnostic Complete</span>
            </div>
            <p className="text-zinc-300 leading-relaxed">{enhancementSummary}</p>
          </div>
        )}
      </div>

      {/* 2. Automatic Subject Masking & Selective Grading */}
      <div className="bg-zinc-900/90 border border-zinc-800/80 rounded-2xl p-4 space-y-3.5 shadow-sm">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-xl bg-indigo-500/10 border border-indigo-500/20 flex items-center justify-center text-indigo-400">
              <ScanEye className="w-4 h-4" />
            </div>
            <div>
              <span className="text-xs font-semibold text-zinc-100">
                Automatic Subject Masking
              </span>
              <p className="text-[11px] text-zinc-400">
                Segment subject for selective adjustments
              </p>
            </div>
          </div>

          {aiMaskState.hasSubjectMask && (
            <button
              type="button"
              onClick={onResetMask}
              title="Clear active mask"
              className="text-xs text-zinc-500 hover:text-zinc-300 flex items-center gap-1"
            >
              <RotateCcw className="w-3 h-3" />
              <span>Clear</span>
            </button>
          )}
        </div>

        {!aiMaskState.hasSubjectMask ? (
          <button
            type="button"
            onClick={onDetectSubject}
            disabled={isAiLoading}
            className="w-full flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl bg-zinc-800 hover:bg-zinc-750 border border-zinc-700/80 text-zinc-200 hover:text-white font-medium text-xs transition disabled:opacity-50"
          >
            {isAiLoading ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin text-sky-400" />
                <span>Detecting subject boundaries...</span>
              </>
            ) : (
              <>
                <ScanEye className="w-4 h-4 text-sky-400" />
                <span>Detect & Generate Subject Mask</span>
              </>
            )}
          </button>
        ) : (
          <div className="space-y-3 pt-1">
            {/* Mask target layer selector */}
            <div className="space-y-1.5">
              <div className="flex items-center justify-between text-xs">
                <span className="text-zinc-300 font-medium">
                  Selective Grading Target
                </span>
                <button
                  type="button"
                  onClick={onToggleMaskOverlay}
                  className="flex items-center gap-1 text-[11px] text-zinc-400 hover:text-zinc-200"
                >
                  {showMaskOverlay ? (
                    <>
                      <Eye className="w-3.5 h-3.5 text-red-400" />
                      <span className="text-red-400 font-semibold">Overlay On</span>
                    </>
                  ) : (
                    <>
                      <EyeOff className="w-3.5 h-3.5" />
                      <span>Show Overlay</span>
                    </>
                  )}
                </button>
              </div>

              <div className="grid grid-cols-3 gap-1.5 p-1 bg-zinc-950 rounded-xl border border-zinc-800/80 text-xs font-semibold">
                {(["all", "subject", "background"] as TargetMaskLayer[]).map(
                  (layer) => (
                    <button
                      key={layer}
                      type="button"
                      onClick={() => onUpdateAiMaskState({ targetLayer: layer })}
                      className={`py-1.5 rounded-lg transition text-center capitalize ${
                        aiMaskState.targetLayer === layer
                          ? "bg-zinc-800 text-white shadow-xs"
                          : "text-zinc-400 hover:text-zinc-200"
                      }`}
                    >
                      {layer === "all" ? "Whole Photo" : layer}
                    </button>
                  )
                )}
              </div>
            </div>

            {/* Quick Portrait Grade Shortcuts */}
            <div className="grid grid-cols-2 gap-2 pt-1">
              <button
                type="button"
                onClick={() => onApplySubjectPreset("pop-subject")}
                className="p-2 bg-zinc-800/80 hover:bg-zinc-700/80 border border-zinc-700/60 rounded-xl text-left transition"
              >
                <span className="text-xs font-semibold text-zinc-200 block">
                  Pop Subject
                </span>
                <span className="text-[10px] text-zinc-400">
                  +Exposure & Clarity on subject
                </span>
              </button>

              <button
                type="button"
                onClick={() => onApplySubjectPreset("dim-background")}
                className="p-2 bg-zinc-800/80 hover:bg-zinc-700/80 border border-zinc-700/60 rounded-xl text-left transition"
              >
                <span className="text-xs font-semibold text-zinc-200 block">
                  Dim Background
                </span>
                <span className="text-[10px] text-zinc-400">
                  -0.4 EV & Vignette on bg
                </span>
              </button>
            </div>
          </div>
        )}
      </div>

      {/* 3. Background Removal & Replacement */}
      <div className="bg-zinc-900/90 border border-zinc-800/80 rounded-2xl p-4 space-y-3.5 shadow-sm">
        <div className="flex items-center gap-2">
          <div className="w-7 h-7 rounded-xl bg-purple-500/10 border border-purple-500/20 flex items-center justify-center text-purple-400">
            <Scissors className="w-4 h-4" />
          </div>
          <div>
            <span className="text-xs font-semibold text-zinc-100">
              Background Removal & Backdrops
            </span>
            <p className="text-[11px] text-zinc-400">
              Cut out subject, add solid backdrops or bokeh blur
            </p>
          </div>
        </div>

        {/* Mode Selector */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-1.5 text-xs font-medium">
          <button
            type="button"
            onClick={() => onUpdateAiMaskState({ backgroundMode: "keep" })}
            className={`p-2 rounded-xl border text-center transition ${
              aiMaskState.backgroundMode === "keep"
                ? "bg-zinc-800 border-sky-500 text-white shadow-xs"
                : "bg-zinc-950 border-zinc-800 text-zinc-400 hover:text-zinc-200"
            }`}
          >
            Keep Original
          </button>
          <button
            type="button"
            onClick={async () => {
              if (!aiMaskState.hasSubjectMask) await onDetectSubject();
              onUpdateAiMaskState({ backgroundMode: "transparent" });
            }}
            className={`p-2 rounded-xl border text-center transition ${
              aiMaskState.backgroundMode === "transparent"
                ? "bg-zinc-800 border-sky-500 text-white shadow-xs"
                : "bg-zinc-950 border-zinc-800 text-zinc-400 hover:text-zinc-200"
            }`}
          >
            Transparent
          </button>
          <button
            type="button"
            onClick={async () => {
              if (!aiMaskState.hasSubjectMask) await onDetectSubject();
              onUpdateAiMaskState({ backgroundMode: "blur" });
            }}
            className={`p-2 rounded-xl border text-center transition ${
              aiMaskState.backgroundMode === "blur"
                ? "bg-zinc-800 border-sky-500 text-white shadow-xs"
                : "bg-zinc-950 border-zinc-800 text-zinc-400 hover:text-zinc-200"
            }`}
          >
            Bokeh Blur
          </button>
          <button
            type="button"
            onClick={async () => {
              if (!aiMaskState.hasSubjectMask) await onDetectSubject();
              onUpdateAiMaskState({ backgroundMode: "solid" });
            }}
            className={`p-2 rounded-xl border text-center transition ${
              aiMaskState.backgroundMode === "solid"
                ? "bg-zinc-800 border-sky-500 text-white shadow-xs"
                : "bg-zinc-950 border-zinc-800 text-zinc-400 hover:text-zinc-200"
            }`}
          >
            Solid Studio
          </button>
        </div>

        {/* Solid Background Color Picker */}
        {aiMaskState.backgroundMode === "solid" && (
          <div className="space-y-2 p-3 bg-zinc-950 rounded-xl border border-zinc-800">
            <span className="text-xs text-zinc-300 font-medium block">
              Choose Studio Backdrop
            </span>
            <div className="flex items-center gap-2 flex-wrap">
              {BACKDROP_COLORS.map((bg) => (
                <button
                  key={bg.value}
                  type="button"
                  onClick={() => onUpdateAiMaskState({ solidBgColor: bg.value })}
                  title={bg.name}
                  className={`w-7 h-7 rounded-full border-2 transition shadow-xs ${
                    aiMaskState.solidBgColor === bg.value
                      ? "border-sky-400 scale-110"
                      : "border-zinc-700"
                  }`}
                  style={{ backgroundColor: bg.value }}
                />
              ))}
              {/* Custom color input */}
              <label
                title="Custom color"
                className="w-7 h-7 rounded-full border-2 border-zinc-700 flex items-center justify-center cursor-pointer bg-zinc-800 text-zinc-400 hover:text-zinc-200"
              >
                <Palette className="w-3.5 h-3.5" />
                <input
                  type="color"
                  value={aiMaskState.solidBgColor}
                  onChange={(e) =>
                    onUpdateAiMaskState({ solidBgColor: e.target.value })
                  }
                  className="sr-only"
                />
              </label>
            </div>
          </div>
        )}

        {/* Blur Radius Slider */}
        {aiMaskState.backgroundMode === "blur" && (
          <div className="space-y-1.5 p-3 bg-zinc-950 rounded-xl border border-zinc-800">
            <div className="flex items-center justify-between text-xs">
              <span className="text-zinc-300 font-medium">
                Bokeh Depth of Field Blur
              </span>
              <span className="font-mono text-zinc-400">
                {aiMaskState.bgBlurRadius}px
              </span>
            </div>
            <input
              type="range"
              min="4"
              max="40"
              value={aiMaskState.bgBlurRadius}
              onChange={(e) =>
                onUpdateAiMaskState({
                  bgBlurRadius: parseInt(e.target.value, 10),
                })
              }
              className="w-full h-2 bg-zinc-800 rounded-lg appearance-none cursor-pointer accent-sky-400"
            />
          </div>
        )}
      </div>

      {/* 4. AI Virtual Studio Relight / Keylight Tool */}
      <div className="bg-zinc-900/90 border border-zinc-800/80 rounded-2xl p-4 space-y-3.5 shadow-sm">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-xl bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-400">
              <Lightbulb className="w-4 h-4" />
            </div>
            <div>
              <span className="text-xs font-semibold text-zinc-100">
                AI Studio Relight & Keylight
              </span>
              <p className="text-[11px] text-zinc-400">
                3D directional illumination & portrait catchlight
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={() => onUpdateVirtualLight({ enabled: !virtualLight.enabled })}
            className={`px-3 py-1 rounded-full text-xs font-semibold transition border ${
              virtualLight.enabled
                ? "bg-amber-500 text-zinc-950 border-amber-400 shadow-sm"
                : "bg-zinc-800 text-zinc-400 border-zinc-700 hover:text-white"
            }`}
          >
            {virtualLight.enabled ? "Active" : "Enable"}
          </button>
        </div>

        {virtualLight.enabled && (
          <div className="space-y-3 pt-1 border-t border-zinc-800/60">
            {/* Quick Lighting Presets */}
            <div className="space-y-1.5">
              <span className="text-[11px] font-medium text-zinc-400">
                Lighting Angle Presets
              </span>
              <div className="grid grid-cols-3 gap-1.5">
                {LIGHT_PRESETS.map((lp) => {
                  const isMatch =
                    Math.abs(virtualLight.x - lp.x) < 0.1 &&
                    Math.abs(virtualLight.y - lp.y) < 0.1;
                  return (
                    <button
                      key={lp.name}
                      type="button"
                      onClick={() =>
                        onUpdateVirtualLight({
                          x: lp.x,
                          y: lp.y,
                          warmth: lp.warmth,
                          color: lp.color,
                        })
                      }
                      className={`text-[11px] py-1 px-2 rounded-lg border transition text-center ${
                        isMatch
                          ? "bg-amber-500/20 border-amber-500/40 text-amber-300 font-medium"
                          : "bg-zinc-950 border-zinc-800 text-zinc-400 hover:text-zinc-200"
                      }`}
                    >
                      {lp.name}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* 2D Interactive Placement Pad */}
            <div className="space-y-1.5">
              <div className="flex items-center justify-between text-xs">
                <span className="text-zinc-400 text-[11px]">
                  Light Position (Click or drag pad)
                </span>
                <span className="font-mono text-[10px] text-zinc-500">
                  {Math.round(virtualLight.x * 100)}% X, {Math.round(virtualLight.y * 100)}% Y
                </span>
              </div>
              <div
                onMouseDown={(e) => {
                  const rect = e.currentTarget.getBoundingClientRect();
                  const x = Math.max(0, Math.min(1, (e.clientX - rect.left) / rect.width));
                  const y = Math.max(0, Math.min(1, (e.clientY - rect.top) / rect.height));
                  onUpdateVirtualLight({ x, y });
                }}
                className="relative w-full h-24 bg-zinc-950 rounded-xl border border-zinc-800 cursor-crosshair overflow-hidden select-none"
              >
                {/* Grid lines */}
                <div className="absolute inset-0 grid grid-cols-3 grid-rows-3 pointer-events-none opacity-15">
                  <div className="border-r border-b border-zinc-600" />
                  <div className="border-r border-b border-zinc-600" />
                  <div className="border-b border-zinc-600" />
                  <div className="border-r border-b border-zinc-600" />
                  <div className="border-r border-b border-zinc-600" />
                  <div className="border-b border-zinc-600" />
                  <div className="border-r border-zinc-600" />
                  <div className="border-r border-zinc-600" />
                  <div />
                </div>
                {/* Simulated light bulb reticle */}
                <div
                  className="absolute w-6 h-6 -ml-3 -mt-3 rounded-full border-2 border-amber-300 bg-amber-400/40 shadow-lg shadow-amber-500/40 flex items-center justify-center pointer-events-none transition-all duration-75"
                  style={{
                    left: `${virtualLight.x * 100}%`,
                    top: `${virtualLight.y * 100}%`,
                  }}
                >
                  <div className="w-1.5 h-1.5 rounded-full bg-white" />
                </div>
              </div>
            </div>

            {/* Light Intensity */}
            <div className="space-y-1">
              <div className="flex items-center justify-between text-xs">
                <span className="text-zinc-300">Light Intensity</span>
                <span className="font-mono text-zinc-400">{virtualLight.intensity}%</span>
              </div>
              <input
                type="range"
                min="0"
                max="100"
                value={virtualLight.intensity}
                onChange={(e) =>
                  onUpdateVirtualLight({ intensity: parseInt(e.target.value, 10) })
                }
                className="w-full h-2 bg-zinc-800 rounded-lg appearance-none cursor-pointer accent-amber-400"
              />
            </div>

            {/* Light Spread / Radius */}
            <div className="space-y-1">
              <div className="flex items-center justify-between text-xs">
                <span className="text-zinc-300">Beam Radius / Spread</span>
                <span className="font-mono text-zinc-400">{virtualLight.radius}%</span>
              </div>
              <input
                type="range"
                min="15"
                max="100"
                value={virtualLight.radius}
                onChange={(e) =>
                  onUpdateVirtualLight({ radius: parseInt(e.target.value, 10) })
                }
                className="w-full h-2 bg-zinc-800 rounded-lg appearance-none cursor-pointer accent-amber-400"
              />
            </div>

            {/* Light Color Temperature / Warmth */}
            <div className="space-y-1">
              <div className="flex items-center justify-between text-xs">
                <span className="text-zinc-300">Light Warmth (Kelvin)</span>
                <span className="font-mono text-zinc-400">
                  {virtualLight.warmth > 0
                    ? `+${virtualLight.warmth} Warm`
                    : virtualLight.warmth < 0
                    ? `${virtualLight.warmth} Cool`
                    : "Neutral"}
                </span>
              </div>
              <input
                type="range"
                min="-50"
                max="50"
                value={virtualLight.warmth}
                onChange={(e) =>
                  onUpdateVirtualLight({ warmth: parseInt(e.target.value, 10) })
                }
                className="w-full h-2 bg-zinc-800 rounded-lg appearance-none cursor-pointer accent-amber-400"
              />
            </div>
          </div>
        )}
      </div>

      {/* 5. AI Sky & Atmosphere Harmonizer */}
      <div className="bg-zinc-900/90 border border-zinc-800/80 rounded-2xl p-4 space-y-3.5 shadow-sm">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-xl bg-sky-500/10 border border-sky-500/20 flex items-center justify-center text-sky-400">
              <CloudSun className="w-4 h-4" />
            </div>
            <div>
              <span className="text-xs font-semibold text-zinc-100">
                AI Sky & Atmosphere Harmonizer
              </span>
              <p className="text-[11px] text-zinc-400">
                Atmospheric color grading & horizon ambient glow
              </p>
            </div>
          </div>
        </div>

        {/* Sky Presets Grid */}
        <div className="grid grid-cols-3 gap-2">
          {SKY_PRESETS.map((sp) => {
            const isSelected = skyAtmosphere.preset === sp.id;
            return (
              <button
                key={sp.id}
                type="button"
                onClick={() => onUpdateSkyAtmosphere({ preset: sp.id })}
                className={`flex flex-col items-center gap-1.5 p-2 rounded-xl border transition ${
                  isSelected
                    ? "bg-zinc-800 border-sky-500/80 text-white shadow-sm ring-1 ring-sky-500/50"
                    : "bg-zinc-950 border-zinc-800 text-zinc-400 hover:text-zinc-200"
                }`}
              >
                <div
                  className={`w-full h-6 rounded-lg bg-gradient-to-r ${sp.colors} shadow-inner`}
                />
                <span className="text-[11px] font-semibold">{sp.name}</span>
              </button>
            );
          })}
        </div>

        {skyAtmosphere.preset !== "none" && (
          <div className="space-y-3 pt-2 border-t border-zinc-800/60">
            {/* Atmospheric Intensity */}
            <div className="space-y-1">
              <div className="flex items-center justify-between text-xs">
                <span className="text-zinc-300">Atmosphere Strength</span>
                <span className="font-mono text-zinc-400">{skyAtmosphere.intensity}%</span>
              </div>
              <input
                type="range"
                min="10"
                max="100"
                value={skyAtmosphere.intensity}
                onChange={(e) =>
                  onUpdateSkyAtmosphere({ intensity: parseInt(e.target.value, 10) })
                }
                className="w-full h-2 bg-zinc-800 rounded-lg appearance-none cursor-pointer accent-sky-400"
              />
            </div>

            {/* Horizon Blend */}
            <div className="space-y-1">
              <div className="flex items-center justify-between text-xs">
                <span className="text-zinc-300">Horizon Depth / Blend</span>
                <span className="font-mono text-zinc-400">{skyAtmosphere.horizonBlend}%</span>
              </div>
              <input
                type="range"
                min="10"
                max="100"
                value={skyAtmosphere.horizonBlend}
                onChange={(e) =>
                  onUpdateSkyAtmosphere({ horizonBlend: parseInt(e.target.value, 10) })
                }
                className="w-full h-2 bg-zinc-800 rounded-lg appearance-none cursor-pointer accent-sky-400"
              />
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
