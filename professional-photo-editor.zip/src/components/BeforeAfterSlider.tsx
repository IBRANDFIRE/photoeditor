import React, { useRef, useState, useEffect } from "react";
import { Columns2, Eye } from "lucide-react";

interface BeforeAfterSliderProps {
  originalCanvas: HTMLCanvasElement | null;
  editedCanvas: HTMLCanvasElement | null;
  className?: string;
}

export const BeforeAfterSlider: React.FC<BeforeAfterSliderProps> = ({
  originalCanvas,
  editedCanvas,
  className = "",
}) => {
  const [sliderPos, setSliderPos] = useState(50); // percentage 0..100
  const [isHoldingBefore, setIsHoldingBefore] = useState(false);
  const containerRef = useRef<HTMLDivElement | null>(null);
  const [isDragging, setIsDragging] = useState(false);

  const updatePosition = (clientX: number) => {
    if (!containerRef.current) return;
    const rect = containerRef.current.getBoundingClientRect();
    const pos = Math.max(0, Math.min(100, ((clientX - rect.left) / rect.width) * 100));
    setSliderPos(pos);
  };

  const handlePointerDown = (e: React.PointerEvent) => {
    (e.target as Element).setPointerCapture?.(e.pointerId);
    setIsDragging(true);
    updatePosition(e.clientX);
  };

  const handlePointerMove = (e: React.PointerEvent) => {
    if (!isDragging) return;
    updatePosition(e.clientX);
  };

  const handlePointerUp = () => {
    setIsDragging(false);
  };

  return (
    <div className={`relative select-none ${className}`}>
      {/* Viewport container */}
      <div
        ref={containerRef}
        onPointerDown={handlePointerDown}
        onPointerMove={handlePointerMove}
        onPointerUp={handlePointerUp}
        className="relative w-full h-full overflow-hidden cursor-ew-resize touch-none rounded-xl"
      >
        {/* Under layer: Edited canvas or image */}
        <div className="absolute inset-0 flex items-center justify-center">
          {editedCanvas && (
            <img
              src={editedCanvas.toDataURL()}
              alt="Edited"
              className="w-full h-full object-contain"
            />
          )}
        </div>

        {/* Top layer: Original canvas, clipped by slider percentage */}
        <div
          className="absolute inset-0 overflow-hidden"
          style={{
            width: isHoldingBefore ? "100%" : `${sliderPos}%`,
          }}
        >
          {originalCanvas && (
            <img
              src={originalCanvas.toDataURL()}
              alt="Original"
              className="w-full h-full object-contain"
              style={{
                width: containerRef.current
                  ? `${containerRef.current.clientWidth}px`
                  : "100%",
                maxWidth: "none",
              }}
            />
          )}
        </div>

        {/* Vertical divider line */}
        {!isHoldingBefore && (
          <div
            className="absolute top-0 bottom-0 w-0.5 bg-white shadow-2xl z-20 pointer-events-none"
            style={{ left: `${sliderPos}%` }}
          >
            {/* Draggable center handle */}
            <div className="absolute top-1/2 -translate-y-1/2 -translate-x-1/2 w-8 h-8 rounded-full bg-zinc-900/90 border-2 border-white shadow-xl flex items-center justify-center text-white">
              <Columns2 className="w-4 h-4 text-zinc-200" />
            </div>
          </div>
        )}

        {/* Badges */}
        <div className="absolute top-3 left-3 px-2 py-0.5 rounded-md bg-black/60 backdrop-blur-md text-[10px] font-semibold text-zinc-300 pointer-events-none z-30">
          BEFORE
        </div>
        <div className="absolute top-3 right-3 px-2 py-0.5 rounded-md bg-black/60 backdrop-blur-md text-[10px] font-semibold text-sky-300 pointer-events-none z-30">
          AFTER
        </div>
      </div>

      {/* Quick Hold to Compare Button for mobile convenience */}
      <div className="absolute bottom-3 right-3 z-30">
        <button
          type="button"
          onMouseDown={() => setIsHoldingBefore(true)}
          onMouseUp={() => setIsHoldingBefore(false)}
          onTouchStart={() => setIsHoldingBefore(true)}
          onTouchEnd={() => setIsHoldingBefore(false)}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-zinc-900/90 border border-zinc-700/80 text-xs font-semibold text-zinc-200 shadow-xl active:bg-sky-500 active:text-white transition"
        >
          <Eye className="w-3.5 h-3.5" />
          <span>Hold for Before</span>
        </button>
      </div>
    </div>
  );
};
