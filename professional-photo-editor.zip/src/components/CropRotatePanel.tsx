import React from "react";
import { CropState, DEFAULT_CROP } from "../types";
import {
  RotateCw,
  FlipHorizontal,
  FlipVertical,
  RotateCcw,
  Maximize2,
} from "lucide-react";

interface CropRotatePanelProps {
  crop: CropState;
  onChange: (crop: CropState) => void;
}

export const CropRotatePanel: React.FC<CropRotatePanelProps> = ({
  crop,
  onChange,
}) => {
  const aspectRatios: {
    id: CropState["aspectRatio"];
    label: string;
    sub: string;
  }[] = [
    { id: "free", label: "Free", sub: "Custom" },
    { id: "1:1", label: "1:1", sub: "Square" },
    { id: "4:5", label: "4:5", sub: "IG Portrait" },
    { id: "9:16", label: "9:16", sub: "Story/Reel" },
    { id: "16:9", label: "16:9", sub: "Widescreen" },
    { id: "3:2", label: "3:2", sub: "35mm Photo" },
    { id: "2:3", label: "2:3", sub: "Photo Port." },
  ];

  const handleRotate90 = () => {
    const nextRot = (crop.rotation + 90) % 360;
    onChange({
      ...crop,
      rotation: nextRot,
    });
  };

  const handleToggleFlipH = () => {
    onChange({
      ...crop,
      flipH: !crop.flipH,
    });
  };

  const handleToggleFlipV = () => {
    onChange({
      ...crop,
      flipV: !crop.flipV,
    });
  };

  const handleStraightenChange = (val: number) => {
    onChange({
      ...crop,
      straighten: val,
    });
  };

  const handleReset = () => {
    onChange(DEFAULT_CROP);
  };

  return (
    <div className="space-y-4">
      {/* Aspect Ratio Presets */}
      <div className="bg-zinc-900/90 border border-zinc-800/80 rounded-2xl p-4 space-y-2.5 shadow-sm">
        <div className="flex items-center justify-between border-b border-zinc-800/60 pb-2">
          <span className="text-xs font-semibold text-zinc-200">
            Aspect Ratio
          </span>
          <button
            type="button"
            onClick={handleReset}
            className="flex items-center gap-1 text-xs text-zinc-400 hover:text-white transition"
          >
            <RotateCcw className="w-3 h-3" />
            <span>Reset Geometry</span>
          </button>
        </div>

        <div className="grid grid-cols-4 sm:grid-cols-7 gap-1.5 text-xs">
          {aspectRatios.map((ar) => (
            <button
              key={ar.id}
              type="button"
              onClick={() => onChange({ ...crop, aspectRatio: ar.id })}
              className={`flex flex-col items-center py-2 px-1 rounded-xl border transition ${
                crop.aspectRatio === ar.id
                  ? "bg-zinc-800 border-sky-500 text-white shadow-xs"
                  : "bg-zinc-950/80 border-zinc-800/80 text-zinc-400 hover:text-zinc-200"
              }`}
            >
              <span className="font-semibold text-xs">{ar.label}</span>
              <span className="text-[9px] text-zinc-500 truncate max-w-full">
                {ar.sub}
              </span>
            </button>
          ))}
        </div>
      </div>

      {/* Rotation & Flip Actions */}
      <div className="bg-zinc-900/90 border border-zinc-800/80 rounded-2xl p-4 space-y-3 shadow-sm">
        <span className="text-xs font-semibold text-zinc-200 block border-b border-zinc-800/60 pb-2">
          Transform & Straighten
        </span>

        <div className="grid grid-cols-3 gap-2">
          <button
            type="button"
            onClick={handleRotate90}
            className="flex items-center justify-center gap-1.5 p-2.5 rounded-xl bg-zinc-800/80 border border-zinc-700/60 hover:bg-zinc-700/80 text-xs font-medium text-zinc-200 transition"
          >
            <RotateCw className="w-4 h-4 text-sky-400" />
            <span>Rotate 90°</span>
          </button>

          <button
            type="button"
            onClick={handleToggleFlipH}
            className={`flex items-center justify-center gap-1.5 p-2.5 rounded-xl border text-xs font-medium transition ${
              crop.flipH
                ? "bg-sky-500/20 border-sky-500 text-sky-300"
                : "bg-zinc-800/80 border-zinc-700/60 hover:bg-zinc-700/80 text-zinc-200"
            }`}
          >
            <FlipHorizontal className="w-4 h-4 text-sky-400" />
            <span>Flip H</span>
          </button>

          <button
            type="button"
            onClick={handleToggleFlipV}
            className={`flex items-center justify-center gap-1.5 p-2.5 rounded-xl border text-xs font-medium transition ${
              crop.flipV
                ? "bg-sky-500/20 border-sky-500 text-sky-300"
                : "bg-zinc-800/80 border-zinc-700/60 hover:bg-zinc-700/80 text-zinc-200"
            }`}
          >
            <FlipVertical className="w-4 h-4 text-sky-400" />
            <span>Flip V</span>
          </button>
        </div>

        {/* Fine Straighten Slider */}
        <div className="space-y-1 pt-1">
          <div className="flex items-center justify-between text-xs">
            <span className="text-zinc-300">Fine Straighten</span>
            <button
              type="button"
              onClick={() => handleStraightenChange(0)}
              className="font-mono text-zinc-400 hover:text-zinc-200"
            >
              {crop.straighten > 0
                ? `+${crop.straighten}°`
                : `${crop.straighten}°`}
            </button>
          </div>
          <input
            type="range"
            min="-45"
            max="45"
            value={crop.straighten}
            onChange={(e) =>
              handleStraightenChange(parseInt(e.target.value, 10))
            }
            className="w-full h-2 bg-zinc-800 rounded-lg appearance-none cursor-pointer accent-sky-400"
          />
        </div>
      </div>
    </div>
  );
};
