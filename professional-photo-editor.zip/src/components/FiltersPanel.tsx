import React, { useState } from "react";
import { FilterPreset } from "../types";
import { FILTER_PRESETS } from "../constants/filters";
import { Sparkles, Check } from "lucide-react";

interface FiltersPanelProps {
  activeFilterId: string | null;
  filterIntensity: number;
  onSelectFilter: (filter: FilterPreset | null) => void;
  onIntensityChange: (intensity: number) => void;
}

export const FiltersPanel: React.FC<FiltersPanelProps> = ({
  activeFilterId,
  filterIntensity,
  onSelectFilter,
  onIntensityChange,
}) => {
  const [selectedCategory, setSelectedCategory] = useState<string>("All");

  const categories = [
    "All",
    "Cinematic",
    "Film & Vintage",
    "Portrait",
    "Monochrome",
    "Landscape",
    "Mood",
  ];

  const filteredPresets =
    selectedCategory === "All"
      ? FILTER_PRESETS
      : FILTER_PRESETS.filter((p) => p.category === selectedCategory);

  return (
    <div className="space-y-4">
      {/* Filter Intensity Slider */}
      <div className="bg-zinc-900/90 border border-zinc-800/80 rounded-2xl p-3.5 space-y-1.5 shadow-sm">
        <div className="flex items-center justify-between text-xs">
          <div className="flex items-center gap-1.5 text-zinc-300 font-medium">
            <Sparkles className="w-3.5 h-3.5 text-sky-400" />
            <span>Filter Intensity</span>
          </div>
          <span className="font-mono text-zinc-400 font-semibold">
            {filterIntensity}%
          </span>
        </div>
        <input
          type="range"
          min="0"
          max="100"
          value={filterIntensity}
          onChange={(e) => onIntensityChange(parseInt(e.target.value, 10))}
          className="w-full h-2 bg-zinc-800 rounded-lg appearance-none cursor-pointer accent-sky-400"
        />
      </div>

      {/* Category Pills */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none text-xs">
        {categories.map((cat) => (
          <button
            key={cat}
            type="button"
            onClick={() => setSelectedCategory(cat)}
            className={`px-3 py-1.5 rounded-xl font-medium whitespace-nowrap transition ${
              selectedCategory === cat
                ? "bg-zinc-700 text-white shadow-xs"
                : "bg-zinc-900 text-zinc-400 hover:text-zinc-200 border border-zinc-800"
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      {/* Preset Cards Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5 max-h-[360px] overflow-y-auto pr-1">
        {/* None / Original */}
        <button
          type="button"
          onClick={() => onSelectFilter(null)}
          className={`flex flex-col items-start text-left p-3 rounded-2xl border transition relative ${
            activeFilterId === null
              ? "bg-zinc-800 border-sky-500/80 shadow-md ring-1 ring-sky-500/50"
              : "bg-zinc-900/80 border-zinc-800/80 hover:border-zinc-700"
          }`}
        >
          <div className="w-full h-12 rounded-xl bg-zinc-950/80 border border-zinc-800 mb-2 flex items-center justify-center text-xs font-mono text-zinc-500">
            RAW / Original
          </div>
          <div className="flex items-center justify-between w-full">
            <span className="font-semibold text-xs text-zinc-200">No Filter</span>
            {activeFilterId === null && (
              <Check className="w-3.5 h-3.5 text-sky-400" />
            )}
          </div>
          <span className="text-[10px] text-zinc-500 mt-0.5">Unfiltered base</span>
        </button>

        {filteredPresets.map((preset) => {
          const isSelected = activeFilterId === preset.id;

          return (
            <button
              key={preset.id}
              type="button"
              onClick={() => onSelectFilter(preset)}
              className={`flex flex-col items-start text-left p-3 rounded-2xl border transition relative group ${
                isSelected
                  ? "bg-zinc-800 border-sky-500/80 shadow-md ring-1 ring-sky-500/50"
                  : "bg-zinc-900/80 border-zinc-800/80 hover:border-zinc-700"
              }`}
            >
              {/* Visual preview swatch */}
              <div
                className="w-full h-12 rounded-xl mb-2 relative overflow-hidden flex items-end p-1.5"
                style={{
                  background: `linear-gradient(135deg, ${preset.accentColor}33 0%, #18181b 100%)`,
                  borderColor: `${preset.accentColor}44`,
                  borderWidth: "1px",
                }}
              >
                <div
                  className="w-3.5 h-3.5 rounded-full shadow-xs"
                  style={{ backgroundColor: preset.accentColor }}
                />
              </div>

              <div className="flex items-center justify-between w-full">
                <span className="font-semibold text-xs text-zinc-200 truncate">
                  {preset.name}
                </span>
                {isSelected && <Check className="w-3.5 h-3.5 text-sky-400 shrink-0" />}
              </div>
              <span className="text-[10px] text-zinc-400 line-clamp-2 mt-0.5">
                {preset.description}
              </span>
            </button>
          );
        })}
      </div>
    </div>
  );
};
