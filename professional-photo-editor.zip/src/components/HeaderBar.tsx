import React, { useRef } from "react";
import { SAMPLE_IMAGES, SampleImage } from "../constants/sampleImages";
import {
  Camera,
  Upload,
  Image as ImageIcon,
  Undo2,
  Redo2,
  Columns2,
  Download,
  Activity,
  ChevronDown,
  RotateCcw,
} from "lucide-react";

interface HeaderBarProps {
  canUndo: boolean;
  canRedo: boolean;
  onUndo: () => void;
  onRedo: () => void;
  onResetAll: () => void;
  isCompareActive: boolean;
  onToggleCompare: () => void;
  isHistogramVisible: boolean;
  onToggleHistogram: () => void;
  onSelectSample: (sample: SampleImage) => void;
  onUploadFile: (file: File) => void;
  onOpenExport: () => void;
}

export const HeaderBar: React.FC<HeaderBarProps> = ({
  canUndo,
  canRedo,
  onUndo,
  onRedo,
  onResetAll,
  isCompareActive,
  onToggleCompare,
  isHistogramVisible,
  onToggleHistogram,
  onSelectSample,
  onUploadFile,
  onOpenExport,
}) => {
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const [samplesOpen, setSamplesOpen] = React.useState(false);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      onUploadFile(e.target.files[0]);
      e.target.value = "";
    }
  };

  return (
    <header className="h-14 bg-zinc-950/95 border-b border-zinc-800/80 px-3 sm:px-5 flex items-center justify-between z-30 shrink-0 select-none">
      {/* Left: Brand & File Operations */}
      <div className="flex items-center gap-2 sm:gap-3">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-sky-500 to-indigo-500 flex items-center justify-center text-white shadow-md shadow-sky-500/20">
            <Camera className="w-4 h-4" />
          </div>
          <div className="hidden sm:block leading-tight">
            <h1 className="text-xs font-bold text-zinc-100 uppercase tracking-wider">
              Studio RAW
            </h1>
            <span className="text-[10px] text-zinc-400 font-mono">
              Pro Grading & Retouch
            </span>
          </div>
        </div>

        <div className="h-4 w-px bg-zinc-800 hidden sm:block" />

        {/* Upload Button */}
        <input
          ref={fileInputRef}
          type="file"
          accept="image/*"
          onChange={handleFileChange}
          className="hidden"
        />
        <button
          type="button"
          onClick={() => fileInputRef.current?.click()}
          className="flex items-center gap-1.5 text-xs font-medium px-2.5 py-1.5 rounded-xl bg-zinc-900 border border-zinc-800 hover:bg-zinc-850 hover:border-zinc-700 text-zinc-200 transition"
        >
          <Upload className="w-3.5 h-3.5 text-sky-400" />
          <span className="hidden xs:inline">Open Photo</span>
        </button>

        {/* Sample Photos Dropdown */}
        <div className="relative">
          <button
            type="button"
            onClick={() => setSamplesOpen(!samplesOpen)}
            className="flex items-center gap-1 text-xs font-medium px-2.5 py-1.5 rounded-xl bg-zinc-900 border border-zinc-800 hover:bg-zinc-850 text-zinc-300 transition"
          >
            <ImageIcon className="w-3.5 h-3.5 text-zinc-400" />
            <span className="hidden md:inline">Sample RAWs</span>
            <ChevronDown className="w-3 h-3 text-zinc-400 ml-0.5" />
          </button>

          {samplesOpen && (
            <>
              <div
                className="fixed inset-0 z-40"
                onClick={() => setSamplesOpen(false)}
              />
              <div className="absolute left-0 mt-1.5 w-60 bg-zinc-900 border border-zinc-800 rounded-2xl p-1.5 shadow-2xl z-50 animate-fadeIn">
                <span className="text-[10px] font-mono text-zinc-500 uppercase px-2.5 py-1 block">
                  Select Pro Demo Sample
                </span>
                {SAMPLE_IMAGES.map((sample) => (
                  <button
                    key={sample.id}
                    type="button"
                    onClick={() => {
                      onSelectSample(sample);
                      setSamplesOpen(false);
                    }}
                    className="w-full flex items-center justify-between p-2 rounded-xl text-left hover:bg-zinc-800 transition"
                  >
                    <div>
                      <div className="text-xs font-medium text-zinc-200">
                        {sample.title}
                      </div>
                      <div className="text-[10px] text-zinc-500">
                        {sample.category} • by {sample.photographer}
                      </div>
                    </div>
                  </button>
                ))}
              </div>
            </>
          )}
        </div>
      </div>

      {/* Center: Undo / Redo / Compare */}
      <div className="flex items-center gap-1 sm:gap-2">
        <button
          type="button"
          onClick={onUndo}
          disabled={!canUndo}
          title="Undo (Ctrl+Z)"
          className="p-2 rounded-xl text-zinc-300 hover:text-white hover:bg-zinc-900 disabled:opacity-30 disabled:pointer-events-none transition"
        >
          <Undo2 className="w-4 h-4" />
        </button>

        <button
          type="button"
          onClick={onRedo}
          disabled={!canRedo}
          title="Redo (Ctrl+Y)"
          className="p-2 rounded-xl text-zinc-300 hover:text-white hover:bg-zinc-900 disabled:opacity-30 disabled:pointer-events-none transition"
        >
          <Redo2 className="w-4 h-4" />
        </button>

        <div className="h-4 w-px bg-zinc-800" />

        <button
          type="button"
          onClick={onToggleCompare}
          title="Toggle Before / After Split View"
          className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl border text-xs font-medium transition ${
            isCompareActive
              ? "bg-sky-500/20 border-sky-500 text-sky-300 shadow-sm"
              : "bg-zinc-900 border-zinc-800 text-zinc-300 hover:bg-zinc-850"
          }`}
        >
          <Columns2 className="w-3.5 h-3.5" />
          <span className="hidden sm:inline">Compare</span>
        </button>

        <button
          type="button"
          onClick={onToggleHistogram}
          title="Toggle Histogram"
          className={`p-2 rounded-xl border transition ${
            isHistogramVisible
              ? "bg-zinc-800 border-zinc-700 text-sky-400"
              : "bg-zinc-900 border-zinc-800 text-zinc-400 hover:text-zinc-200"
          }`}
        >
          <Activity className="w-4 h-4" />
        </button>

        <button
          type="button"
          onClick={onResetAll}
          title="Reset all edits"
          className="p-2 rounded-xl text-zinc-400 hover:text-red-400 hover:bg-zinc-900 transition"
        >
          <RotateCcw className="w-4 h-4" />
        </button>
      </div>

      {/* Right: High-Res Export Action */}
      <div className="flex items-center gap-2">
        <button
          type="button"
          onClick={onOpenExport}
          className="flex items-center gap-1.5 text-xs font-semibold px-3 sm:px-4 py-1.5 rounded-xl bg-gradient-to-r from-sky-500 to-indigo-600 hover:from-sky-400 hover:to-indigo-500 text-white shadow-lg shadow-sky-500/20 transition active:scale-95"
        >
          <Download className="w-3.5 h-3.5" />
          <span>Export High-Res</span>
        </button>
      </div>
    </header>
  );
};
