import React from "react";
import { RetouchTool } from "../types";
import {
  Bandage,
  Sparkles,
  SunMedium,
  Moon,
  Smile,
  Focus,
  Eraser,
  Stamp,
  Eye,
  Droplet,
  Undo2,
  Trash2,
  Wand2,
} from "lucide-react";

interface RetouchToolbarProps {
  activeTool: RetouchTool;
  brushSize: number;
  brushOpacity: number;
  strokesCount: number;
  cloneSourcePoint?: { x: number; y: number } | null;
  onSelectTool: (tool: RetouchTool) => void;
  onSizeChange: (size: number) => void;
  onOpacityChange: (opacity: number) => void;
  onUndoStroke: () => void;
  onClearStrokes: () => void;
  onApplyInpaint?: () => void;
}

export const RetouchToolbar: React.FC<RetouchToolbarProps> = ({
  activeTool,
  brushSize,
  brushOpacity,
  strokesCount,
  cloneSourcePoint,
  onSelectTool,
  onSizeChange,
  onOpacityChange,
  onUndoStroke,
  onClearStrokes,
  onApplyInpaint,
}) => {
  const tools: { id: RetouchTool; name: string; icon: any; desc: string; badge?: string }[] = [
    {
      id: "eraser",
      name: "AI Eraser",
      icon: Eraser,
      desc: "Inpaint & remove unwanted objects, people, powerlines",
      badge: "AI",
    },
    {
      id: "heal",
      name: "Spot Heal",
      icon: Bandage,
      desc: "Remove blemishes, acne, stray marks",
    },
    {
      id: "clone",
      name: "Clone Stamp",
      icon: Stamp,
      desc: "Sample texture and clone over blemishes",
    },
    {
      id: "smooth",
      name: "Skin Smooth",
      icon: Sparkles,
      desc: "Even out skin texture and pores",
    },
    {
      id: "dodge",
      name: "Dodge",
      icon: SunMedium,
      desc: "Lighten highlights and brighten eyes",
    },
    {
      id: "burn",
      name: "Burn",
      icon: Moon,
      desc: "Darken shadows and sculpt contours",
    },
    {
      id: "whiten",
      name: "Whiten",
      icon: Smile,
      desc: "Whiten teeth & brighten sclera",
    },
    {
      id: "sharpen",
      name: "Detail Sharp",
      icon: Focus,
      desc: "Crisp focus on irises & lashes",
    },
    {
      id: "redeye",
      name: "Red-Eye Fix",
      icon: Eye,
      desc: "Neutralize camera flash pupil glare",
    },
    {
      id: "splash",
      name: "Color Splash",
      icon: Droplet,
      desc: "Boost vibrant saturation on brushed areas",
    },
  ];

  const activeMeta = tools.find((t) => t.id === activeTool) || tools[0];

  return (
    <div className="space-y-4">
      {/* Tool Selector Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
        {tools.map((t) => {
          const Icon = t.icon;
          const isSelected = activeTool === t.id;

          return (
            <button
              key={t.id}
              type="button"
              onClick={() => onSelectTool(t.id)}
              className={`relative flex flex-col items-center gap-1.5 p-2.5 rounded-2xl border transition ${
                isSelected
                  ? "bg-zinc-800 border-sky-500/80 text-white shadow-sm ring-1 ring-sky-500/50"
                  : "bg-zinc-900/80 border-zinc-800/80 text-zinc-400 hover:text-zinc-200 hover:bg-zinc-900"
              }`}
            >
              {t.badge && (
                <span className="absolute top-1.5 right-1.5 px-1.5 py-0.5 rounded-full bg-sky-500/20 text-sky-400 text-[9px] font-bold border border-sky-500/30">
                  {t.badge}
                </span>
              )}
              <Icon className="w-5 h-5" />
              <span className="text-[11px] font-semibold whitespace-nowrap">
                {t.name}
              </span>
            </button>
          );
        })}
      </div>

      {/* Brush Settings Card */}
      <div className="bg-zinc-900/90 border border-zinc-800/80 rounded-2xl p-4 space-y-3.5 shadow-sm">
        <div className="flex items-center justify-between border-b border-zinc-800/60 pb-2">
          <div>
            <div className="flex items-center gap-1.5">
              <span className="text-xs font-semibold text-zinc-200">
                {activeMeta.name} Brush
              </span>
              {activeMeta.badge && (
                <span className="px-1.5 py-0.5 rounded text-[9px] font-bold bg-sky-500/20 text-sky-400 border border-sky-500/30">
                  {activeMeta.badge}
                </span>
              )}
            </div>
            <p className="text-[11px] text-zinc-400">{activeMeta.desc}</p>
          </div>

          <div className="flex items-center gap-1.5">
            <button
              type="button"
              onClick={onUndoStroke}
              disabled={strokesCount === 0}
              title="Undo last brush stroke"
              className="flex items-center gap-1 text-xs px-2.5 py-1 rounded-lg bg-zinc-800 text-zinc-300 hover:text-white disabled:opacity-40 disabled:pointer-events-none transition"
            >
              <Undo2 className="w-3.5 h-3.5" />
              <span>Undo</span>
            </button>
            <button
              type="button"
              onClick={onClearStrokes}
              disabled={strokesCount === 0}
              title="Clear all retouch strokes"
              className="flex items-center gap-1 text-xs px-2.5 py-1 rounded-lg bg-zinc-800 text-red-400 hover:text-red-300 disabled:opacity-40 disabled:pointer-events-none transition"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>Clear ({strokesCount})</span>
            </button>
          </div>
        </div>

        {/* AI Eraser Action Button */}
        {activeTool === "eraser" && onApplyInpaint && (
          <div className="p-2.5 rounded-xl bg-sky-500/10 border border-sky-500/20 flex items-center justify-between">
            <div className="text-[11px] text-sky-300 flex items-center gap-1.5">
              <Wand2 className="w-3.5 h-3.5 text-sky-400" />
              <span>Paint over object, then inpaint to synthesize background.</span>
            </div>
            <button
              type="button"
              onClick={onApplyInpaint}
              className="px-3 py-1 text-xs font-semibold rounded-lg bg-sky-500 hover:bg-sky-400 text-white shadow transition"
            >
              Inpaint Object
            </button>
          </div>
        )}

        {/* Clone Stamp info */}
        {activeTool === "clone" && (
          <div className="p-2.5 rounded-xl bg-amber-500/10 border border-amber-500/20 text-[11px] text-amber-300 flex items-center gap-1.5">
            <Stamp className="w-3.5 h-3.5 text-amber-400 shrink-0" />
            <span>
              {cloneSourcePoint
                ? `Clone Source: (${Math.round(cloneSourcePoint.x)}, ${Math.round(cloneSourcePoint.y)}). Brush to duplicate.`
                : "Alt-Click or tap once on the photo to set the sample texture source pin."}
            </span>
          </div>
        )}

        {/* Brush Size */}
        <div className="space-y-1">
          <div className="flex items-center justify-between text-xs">
            <span className="text-zinc-300">Brush Size</span>
            <span className="font-mono text-zinc-400">{brushSize}px</span>
          </div>
          <input
            type="range"
            min="6"
            max="180"
            value={brushSize}
            onChange={(e) => onSizeChange(parseInt(e.target.value, 10))}
            className="w-full h-2 bg-zinc-800 rounded-lg appearance-none cursor-pointer accent-sky-400"
          />
        </div>

        {/* Brush Opacity / Flow */}
        <div className="space-y-1">
          <div className="flex items-center justify-between text-xs">
            <span className="text-zinc-300">Brush Flow / Strength</span>
            <span className="font-mono text-zinc-400">
              {Math.round(brushOpacity * 100)}%
            </span>
          </div>
          <input
            type="range"
            min="0.1"
            max="1.0"
            step="0.05"
            value={brushOpacity}
            onChange={(e) => onOpacityChange(parseFloat(e.target.value))}
            className="w-full h-2 bg-zinc-800 rounded-lg appearance-none cursor-pointer accent-sky-400"
          />
        </div>
      </div>

      <p className="text-center text-[11px] text-zinc-400">
        Brush directly over areas of the photo in the viewport. Retouches render dynamically.
      </p>
    </div>
  );
};

