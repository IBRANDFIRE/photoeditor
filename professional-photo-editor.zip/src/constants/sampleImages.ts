export interface SampleImage {
  id: string;
  title: string;
  category: "Portrait" | "Street" | "Landscape" | "Architecture" | "Still Life";
  url: string;
  photographer: string;
}

export const SAMPLE_IMAGES: SampleImage[] = [
  {
    id: "portrait-golden",
    title: "Golden Hour Portrait",
    category: "Portrait",
    url: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=1400&q=85",
    photographer: "Aiony Haust",
  },
  {
    id: "street-cinematic",
    title: "Tokyo Neon Alley",
    category: "Street",
    url: "https://images.unsplash.com/photo-1503899036084-c55cdd92da26?auto=format&fit=crop&w=1400&q=85",
    photographer: "Aleksandar Pasaric",
  },
  {
    id: "landscape-mountains",
    title: "Dolomites Alpine Peaks",
    category: "Landscape",
    url: "https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?auto=format&fit=crop&w=1400&q=85",
    photographer: "Kalen Emsley",
  },
  {
    id: "portrait-studio",
    title: "Editorial Studio Model",
    category: "Portrait",
    url: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=1400&q=85",
    photographer: "Joseph Gonzalez",
  },
  {
    id: "architecture-modern",
    title: "Minimalist Geometry",
    category: "Architecture",
    url: "https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&w=1400&q=85",
    photographer: "Simone Hutsch",
  },
];
