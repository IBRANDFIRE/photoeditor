export interface Adjustments {
  exposure: number;     // -5.0 to +5.0 EV
  contrast: number;     // -100 to +100
  highlights: number;   // -100 to +100
  shadows: number;      // -100 to +100
  whites: number;       // -100 to +100
  blacks: number;       // -100 to +100
  temperature: number;  // -100 to +100 (Cool to Warm)
  tint: number;         // -100 to +100 (Green to Magenta)
  vibrance: number;     // -100 to +100
  saturation: number;   // -100 to +100
  clarity: number;      // -100 to +100
  texture: number;      // -100 to +100
  dehaze: number;       // -100 to +100
  vignette: number;     // -100 to +100
  grain: number;        // 0 to 100
  sharpen: number;      // 0 to 100
}

export const DEFAULT_ADJUSTMENTS: Adjustments = {
  exposure: 0,
  contrast: 0,
  highlights: 0,
  shadows: 0,
  whites: 0,
  blacks: 0,
  temperature: 0,
  tint: 0,
  vibrance: 0,
  saturation: 0,
  clarity: 0,
  texture: 0,
  dehaze: 0,
  vignette: 0,
  grain: 0,
  sharpen: 0,
};

export interface ColorWheelValue {
  hue: number;        // 0 to 360
  saturation: number; // 0 to 100
  luminance: number;  // -100 to +100
}

export interface ColorGrading {
  shadows: ColorWheelValue;
  midtones: ColorWheelValue;
  highlights: ColorWheelValue;
  blending: number; // 0 to 100
  balance: number;  // -100 to +100
}

export const DEFAULT_COLOR_GRADING: ColorGrading = {
  shadows: { hue: 0, saturation: 0, luminance: 0 },
  midtones: { hue: 0, saturation: 0, luminance: 0 },
  highlights: { hue: 0, saturation: 0, luminance: 0 },
  blending: 50,
  balance: 0,
};

export type HslChannel =
  | "red"
  | "orange"
  | "yellow"
  | "green"
  | "aqua"
  | "blue"
  | "purple"
  | "magenta";

export interface HslChannelValue {
  hue: number;        // -100 to +100
  saturation: number; // -100 to +100
  lightness: number;  // -100 to +100
}

export type HslGrading = Record<HslChannel, HslChannelValue>;

export const DEFAULT_HSL_GRADING: HslGrading = {
  red: { hue: 0, saturation: 0, lightness: 0 },
  orange: { hue: 0, saturation: 0, lightness: 0 },
  yellow: { hue: 0, saturation: 0, lightness: 0 },
  green: { hue: 0, saturation: 0, lightness: 0 },
  aqua: { hue: 0, saturation: 0, lightness: 0 },
  blue: { hue: 0, saturation: 0, lightness: 0 },
  purple: { hue: 0, saturation: 0, lightness: 0 },
  magenta: { hue: 0, saturation: 0, lightness: 0 },
};

export interface CurvePoint {
  x: number; // 0 to 255
  y: number; // 0 to 255
}

export interface ToneCurves {
  rgb: CurvePoint[];
  red: CurvePoint[];
  green: CurvePoint[];
  blue: CurvePoint[];
}

export const DEFAULT_CURVES: ToneCurves = {
  rgb: [
    { x: 0, y: 0 },
    { x: 255, y: 255 },
  ],
  red: [
    { x: 0, y: 0 },
    { x: 255, y: 255 },
  ],
  green: [
    { x: 0, y: 0 },
    { x: 255, y: 255 },
  ],
  blue: [
    { x: 0, y: 0 },
    { x: 255, y: 255 },
  ],
};

export interface FilterPreset {
  id: string;
  name: string;
  category: "Cinematic" | "Film & Vintage" | "Portrait" | "Monochrome" | "Landscape" | "Mood";
  description: string;
  accentColor: string;
  adjustments?: Partial<Adjustments>;
  colorGrading?: Partial<ColorGrading>;
  hsl?: Partial<HslGrading>;
  curves?: Partial<ToneCurves>;
}

export type RetouchTool =
  | "heal"
  | "smooth"
  | "dodge"
  | "burn"
  | "whiten"
  | "sharpen"
  | "eraser"
  | "clone"
  | "redeye"
  | "splash";

export interface RetouchStroke {
  id: string;
  tool: RetouchTool;
  points: { x: number; y: number }[];
  size: number;
  feather: number;
  opacity: number;
  sourcePoint?: { x: number; y: number };
}

export interface VirtualLight {
  enabled: boolean;
  x: number; // 0.0 to 1.0 (normalized)
  y: number; // 0.0 to 1.0 (normalized)
  intensity: number; // 0 to 100
  radius: number; // 10 to 100
  warmth: number; // -50 to +50 (Cool blue to Tungsten amber)
  color: string; // hex string
}

export const DEFAULT_VIRTUAL_LIGHT: VirtualLight = {
  enabled: false,
  x: 0.35,
  y: 0.3,
  intensity: 45,
  radius: 40,
  warmth: 15,
  color: "#ffc87a",
};

export type SkyPreset = "none" | "sunset" | "dusk" | "golden" | "starry" | "azure";

export interface SkyAtmosphere {
  preset: SkyPreset;
  intensity: number; // 0 to 100
  horizonBlend: number; // 0 to 100
}

export const DEFAULT_SKY_ATMOSPHERE: SkyAtmosphere = {
  preset: "none",
  intensity: 65,
  horizonBlend: 45,
};

export type TargetMaskLayer = "all" | "subject" | "background";

export interface AiMaskState {
  hasSubjectMask: boolean;
  maskCanvas: HTMLCanvasElement | null;
  subjectDescription?: string;
  targetLayer: TargetMaskLayer;
  backgroundMode: "keep" | "transparent" | "blur" | "solid";
  solidBgColor: string;
  bgBlurRadius: number;
}

export interface CropState {
  aspectRatio: "free" | "1:1" | "4:5" | "9:16" | "16:9" | "3:2" | "2:3";
  rotation: number;     // 0, 90, 180, 270
  straighten: number;   // -45 to +45
  flipH: boolean;
  flipV: boolean;
  cropRect: { x: number; y: number; width: number; height: number } | null;
}

export const DEFAULT_CROP: CropState = {
  aspectRatio: "free",
  rotation: 0,
  straighten: 0,
  flipH: false,
  flipV: false,
  cropRect: null,
};

export interface EditState {
  adjustments: Adjustments;
  colorGrading: ColorGrading;
  hsl: HslGrading;
  curves: ToneCurves;
  activeFilterId: string | null;
  filterIntensity: number; // 0 to 100
  crop: CropState;
  retouchStrokes: RetouchStroke[];
  virtualLight: VirtualLight;
  skyAtmosphere: SkyAtmosphere;
}

export type ActiveTab =
  | "adjust"
  | "color"
  | "curves"
  | "hsl"
  | "filters"
  | "retouch"
  | "ai"
  | "crop"
  | "relight";

export interface ExportSettings {
  format: "jpeg" | "png" | "webp";
  quality: number; // 50 to 100
  scale: 0.5 | 0.75 | 1 | 2;
  watermark: boolean;
  watermarkText: string;
  filename: string;
}
