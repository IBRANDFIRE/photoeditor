import { RetouchStroke, RetouchTool } from "../types";
import { clamp, rgbToHsl, hslToRgb } from "./imageProcessing";

// Apply a single retouch stroke onto target canvas context
export function applyRetouchStroke(
  ctx: CanvasRenderingContext2D,
  stroke: RetouchStroke,
  canvasWidth: number,
  canvasHeight: number
) {
  const { tool, points, size, opacity } = stroke;
  if (!points || points.length === 0) return;

  const radius = Math.max(4, size / 2);

  switch (tool) {
    case "heal":
      applySpotHealing(ctx, points, radius, opacity, canvasWidth, canvasHeight);
      break;
    case "smooth":
      applySkinSmoothing(ctx, points, radius, opacity, canvasWidth, canvasHeight);
      break;
    case "dodge":
      applyDodgeBurn(ctx, points, radius, opacity, 1, canvasWidth, canvasHeight);
      break;
    case "burn":
      applyDodgeBurn(ctx, points, radius, opacity, -1, canvasWidth, canvasHeight);
      break;
    case "whiten":
      applyTeethWhiten(ctx, points, radius, opacity, canvasWidth, canvasHeight);
      break;
    case "sharpen":
      applySharpenBrush(ctx, points, radius, opacity, canvasWidth, canvasHeight);
      break;
    case "eraser":
      applyObjectEraserStroke(ctx, points, radius, opacity, canvasWidth, canvasHeight);
      break;
    case "clone":
      applyCloneStamp(ctx, points, radius, opacity, stroke.sourcePoint, canvasWidth, canvasHeight);
      break;
    case "redeye":
      applyRedEyeFix(ctx, points, radius, opacity, canvasWidth, canvasHeight);
      break;
    case "splash":
      applyColorSplash(ctx, points, radius, opacity, canvasWidth, canvasHeight);
      break;
  }
}

// Re-apply all retouch strokes on top of clean base canvas
export function applyAllRetouchStrokes(
  ctx: CanvasRenderingContext2D,
  strokes: RetouchStroke[],
  width: number,
  height: number
) {
  for (const stroke of strokes) {
    applyRetouchStroke(ctx, stroke, width, height);
  }
}

// 1. Spot / Blemish Healing: blends surrounding texture to seamlessly remove blemishes
function applySpotHealing(
  ctx: CanvasRenderingContext2D,
  points: { x: number; y: number }[],
  radius: number,
  opacity: number,
  canvasWidth: number,
  canvasHeight: number
) {
  for (const pt of points) {
    const minX = Math.max(0, Math.floor(pt.x - radius * 1.5));
    const minY = Math.max(0, Math.floor(pt.y - radius * 1.5));
    const maxX = Math.min(canvasWidth - 1, Math.ceil(pt.x + radius * 1.5));
    const maxY = Math.min(canvasHeight - 1, Math.ceil(pt.y + radius * 1.5));
    const patchW = maxX - minX;
    const patchH = maxY - minY;

    if (patchW <= 0 || patchH <= 0) continue;

    const imgData = ctx.getImageData(minX, minY, patchW, patchH);
    const data = imgData.data;

    // Collect outer ring pixels to compute average ambient color and texture
    let ringR = 0;
    let ringG = 0;
    let ringB = 0;
    let ringCount = 0;

    for (let y = 0; y < patchH; y++) {
      for (let x = 0; x < patchW; x++) {
        const px = minX + x;
        const py = minY + y;
        const dist = Math.hypot(px - pt.x, py - pt.y);

        // Ring perimeter: between radius * 1.0 and radius * 1.4
        if (dist >= radius * 0.95 && dist <= radius * 1.4) {
          const idx = (y * patchW + x) * 4;
          ringR += data[idx];
          ringG += data[idx + 1];
          ringB += data[idx + 2];
          ringCount++;
        }
      }
    }

    if (ringCount === 0) continue;
    const avgR = ringR / ringCount;
    const avgG = ringG / ringCount;
    const avgB = ringB / ringCount;

    // Blend inner circle with smooth cosine falloff towards ambient ring
    for (let y = 0; y < patchH; y++) {
      for (let x = 0; x < patchW; x++) {
        const px = minX + x;
        const py = minY + y;
        const dist = Math.hypot(px - pt.x, py - pt.y);

        if (dist <= radius) {
          const idx = (y * patchW + x) * 4;
          // Smooth falloff factor (1 at center, 0 at radius)
          const falloff = Math.cos((dist / radius) * (Math.PI / 2)) * opacity;

          data[idx] = clamp(data[idx] * (1 - falloff) + avgR * falloff);
          data[idx + 1] = clamp(data[idx + 1] * (1 - falloff) + avgG * falloff);
          data[idx + 2] = clamp(data[idx + 2] * (1 - falloff) + avgB * falloff);
        }
      }
    }

    ctx.putImageData(imgData, minX, minY);
  }
}

// 2. Skin Smoothing: Bilateral-style local edge-preserving skin softening
function applySkinSmoothing(
  ctx: CanvasRenderingContext2D,
  points: { x: number; y: number }[],
  radius: number,
  opacity: number,
  canvasWidth: number,
  canvasHeight: number
) {
  for (const pt of points) {
    const minX = Math.max(0, Math.floor(pt.x - radius));
    const minY = Math.max(0, Math.floor(pt.y - radius));
    const maxX = Math.min(canvasWidth - 1, Math.ceil(pt.x + radius));
    const maxY = Math.min(canvasHeight - 1, Math.ceil(pt.y + radius));
    const patchW = maxX - minX;
    const patchH = maxY - minY;

    if (patchW <= 2 || patchH <= 2) continue;

    const imgData = ctx.getImageData(minX, minY, patchW, patchH);
    const src = new Uint8ClampedArray(imgData.data);
    const data = imgData.data;

    const blurRadius = Math.max(2, Math.floor(radius / 4));

    for (let y = 0; y < patchH; y++) {
      for (let x = 0; x < patchW; x++) {
        const px = minX + x;
        const py = minY + y;
        const dist = Math.hypot(px - pt.x, py - pt.y);

        if (dist > radius) continue;

        const centerIdx = (y * patchW + x) * 4;
        const centerR = src[centerIdx];
        const centerG = src[centerIdx + 1];
        const centerB = src[centerIdx + 2];

        let sumR = 0, sumG = 0, sumB = 0, totalW = 0;

        // Sample neighborhood
        for (let dy = -blurRadius; dy <= blurRadius; dy++) {
          const ny = y + dy;
          if (ny < 0 || ny >= patchH) continue;
          for (let dx = -blurRadius; dx <= blurRadius; dx++) {
            const nx = x + dx;
            if (nx < 0 || nx >= patchW) continue;

            const nIdx = (ny * patchW + nx) * 4;
            const nr = src[nIdx];
            const ng = src[nIdx + 1];
            const nb = src[nIdx + 2];

            // Color distance (edge preservation threshold)
            const colorDist = Math.hypot(nr - centerR, ng - centerG, nb - centerB);
            if (colorDist < 45) {
              const spatialW = 1 / (1 + Math.hypot(dx, dy));
              const colorW = Math.exp(-(colorDist * colorDist) / 800);
              const w = spatialW * colorW;
              sumR += nr * w;
              sumG += ng * w;
              sumB += nb * w;
              totalW += w;
            }
          }
        }

        if (totalW > 0) {
          const smoothR = sumR / totalW;
          const smoothG = sumG / totalW;
          const smoothB = sumB / totalW;

          const falloff = Math.cos((dist / radius) * (Math.PI / 2)) * opacity * 0.75;
          data[centerIdx] = clamp(src[centerIdx] * (1 - falloff) + smoothR * falloff);
          data[centerIdx + 1] = clamp(src[centerIdx + 1] * (1 - falloff) + smoothG * falloff);
          data[centerIdx + 2] = clamp(src[centerIdx + 2] * (1 - falloff) + smoothB * falloff);
        }
      }
    }

    ctx.putImageData(imgData, minX, minY);
  }
}

// 3. Dodge & Burn (direction: +1 for Dodge/Lighten, -1 for Burn/Darken)
function applyDodgeBurn(
  ctx: CanvasRenderingContext2D,
  points: { x: number; y: number }[],
  radius: number,
  opacity: number,
  direction: 1 | -1,
  canvasWidth: number,
  canvasHeight: number
) {
  for (const pt of points) {
    const minX = Math.max(0, Math.floor(pt.x - radius));
    const minY = Math.max(0, Math.floor(pt.y - radius));
    const maxX = Math.min(canvasWidth - 1, Math.ceil(pt.x + radius));
    const maxY = Math.min(canvasHeight - 1, Math.ceil(pt.y + radius));
    const patchW = maxX - minX;
    const patchH = maxY - minY;

    if (patchW <= 0 || patchH <= 0) continue;

    const imgData = ctx.getImageData(minX, minY, patchW, patchH);
    const data = imgData.data;

    for (let y = 0; y < patchH; y++) {
      for (let x = 0; x < patchW; x++) {
        const px = minX + x;
        const py = minY + y;
        const dist = Math.hypot(px - pt.x, py - pt.y);

        if (dist <= radius) {
          const idx = (y * patchW + x) * 4;
          const falloff = Math.cos((dist / radius) * (Math.PI / 2)) * opacity * 0.35;

          const factor = 1 + direction * falloff;
          data[idx] = clamp(data[idx] * factor);
          data[idx + 1] = clamp(data[idx + 1] * factor);
          data[idx + 2] = clamp(data[idx + 2] * factor);
        }
      }
    }

    ctx.putImageData(imgData, minX, minY);
  }
}

// 4. Teeth & Eye Whitening
function applyTeethWhiten(
  ctx: CanvasRenderingContext2D,
  points: { x: number; y: number }[],
  radius: number,
  opacity: number,
  canvasWidth: number,
  canvasHeight: number
) {
  for (const pt of points) {
    const minX = Math.max(0, Math.floor(pt.x - radius));
    const minY = Math.max(0, Math.floor(pt.y - radius));
    const maxX = Math.min(canvasWidth - 1, Math.ceil(pt.x + radius));
    const maxY = Math.min(canvasHeight - 1, Math.ceil(pt.y + radius));
    const patchW = maxX - minX;
    const patchH = maxY - minY;

    if (patchW <= 0 || patchH <= 0) continue;

    const imgData = ctx.getImageData(minX, minY, patchW, patchH);
    const data = imgData.data;

    for (let y = 0; y < patchH; y++) {
      for (let x = 0; x < patchW; x++) {
        const px = minX + x;
        const py = minY + y;
        const dist = Math.hypot(px - pt.x, py - pt.y);

        if (dist <= radius) {
          const idx = (y * patchW + x) * 4;
          const falloff = Math.cos((dist / radius) * (Math.PI / 2)) * opacity * 0.45;

          const [h, s, l] = rgbToHsl(data[idx], data[idx + 1], data[idx + 2]);

          // Desaturate yellows/reds and lift luminance
          const newS = Math.max(0, s * (1 - falloff * 0.75));
          const newL = Math.min(1, l + falloff * 0.2);

          const [nr, ng, nb] = hslToRgb(h, newS, newL);
          data[idx] = nr;
          data[idx + 1] = ng;
          data[idx + 2] = nb;
        }
      }
    }

    ctx.putImageData(imgData, minX, minY);
  }
}

// 5. Sharpen Brush: brings out crisp focus in eyes, jewelry, hair
function applySharpenBrush(
  ctx: CanvasRenderingContext2D,
  points: { x: number; y: number }[],
  radius: number,
  opacity: number,
  canvasWidth: number,
  canvasHeight: number
) {
  for (const pt of points) {
    const minX = Math.max(1, Math.floor(pt.x - radius));
    const minY = Math.max(1, Math.floor(pt.y - radius));
    const maxX = Math.min(canvasWidth - 2, Math.ceil(pt.x + radius));
    const maxY = Math.min(canvasHeight - 2, Math.ceil(pt.y + radius));
    const patchW = maxX - minX;
    const patchH = maxY - minY;

    if (patchW <= 2 || patchH <= 2) continue;

    const imgData = ctx.getImageData(minX - 1, minY - 1, patchW + 2, patchH + 2);
    const src = imgData.data;
    const stride = (patchW + 2) * 4;

    const outData = ctx.getImageData(minX, minY, patchW, patchH);
    const dst = outData.data;

    for (let y = 0; y < patchH; y++) {
      for (let x = 0; x < patchW; x++) {
        const px = minX + x;
        const py = minY + y;
        const dist = Math.hypot(px - pt.x, py - pt.y);

        if (dist <= radius) {
          const sIdx = ((y + 1) * (patchW + 2) + (x + 1)) * 4;
          const dIdx = (y * patchW + x) * 4;
          const falloff = Math.cos((dist / radius) * (Math.PI / 2)) * opacity * 0.6;

          for (let c = 0; c < 3; c++) {
            const center = src[sIdx + c];
            const up = src[sIdx - stride + c];
            const down = src[sIdx + stride + c];
            const left = src[sIdx - 4 + c];
            const right = src[sIdx + 4 + c];
            const laplacian = 4 * center - up - down - left - right;

            dst[dIdx + c] = clamp(center + laplacian * falloff);
          }
        }
      }
    }

    ctx.putImageData(outData, minX, minY);
  }
}

// 6. AI Object Eraser Brush: synthesizes seamless surrounding texture to remove unwanted elements
function applyObjectEraserStroke(
  ctx: CanvasRenderingContext2D,
  points: { x: number; y: number }[],
  radius: number,
  opacity: number,
  canvasWidth: number,
  canvasHeight: number
) {
  for (const pt of points) {
    const minX = Math.max(0, Math.floor(pt.x - radius * 1.6));
    const minY = Math.max(0, Math.floor(pt.y - radius * 1.6));
    const maxX = Math.min(canvasWidth - 1, Math.ceil(pt.x + radius * 1.6));
    const maxY = Math.min(canvasHeight - 1, Math.ceil(pt.y + radius * 1.6));
    const patchW = maxX - minX;
    const patchH = maxY - minY;

    if (patchW <= 2 || patchH <= 2) continue;

    const imgData = ctx.getImageData(minX, minY, patchW, patchH);
    const data = imgData.data;

    // Sample perimeter band (between 1.05 and 1.5 radius)
    let ringR = 0, ringG = 0, ringB = 0, ringCount = 0;
    const outerRadius = radius * 1.5;
    const innerRadius = radius * 1.05;

    for (let y = 0; y < patchH; y++) {
      for (let x = 0; x < patchW; x++) {
        const px = minX + x;
        const py = minY + y;
        const dist = Math.hypot(px - pt.x, py - pt.y);

        if (dist >= innerRadius && dist <= outerRadius) {
          const idx = (y * patchW + x) * 4;
          ringR += data[idx];
          ringG += data[idx + 1];
          ringB += data[idx + 2];
          ringCount++;
        }
      }
    }

    if (ringCount === 0) continue;
    const avgR = ringR / ringCount;
    const avgG = ringG / ringCount;
    const avgB = ringB / ringCount;

    // Diffuse surrounding tones into the erased core
    for (let y = 0; y < patchH; y++) {
      for (let x = 0; x < patchW; x++) {
        const px = minX + x;
        const py = minY + y;
        const dist = Math.hypot(px - pt.x, py - pt.y);

        if (dist <= radius) {
          const idx = (y * patchW + x) * 4;
          const falloff = Math.cos((dist / radius) * (Math.PI / 2)) * opacity;
          // Organic texture noise to prevent artificial flat patches
          const jitter = (Math.random() - 0.5) * 3;

          data[idx] = clamp(data[idx] * (1 - falloff) + (avgR + jitter) * falloff);
          data[idx + 1] = clamp(data[idx + 1] * (1 - falloff) + (avgG + jitter) * falloff);
          data[idx + 2] = clamp(data[idx + 2] * (1 - falloff) + (avgB + jitter) * falloff);
        }
      }
    }

    ctx.putImageData(imgData, minX, minY);
  }
}

// 7. Clone Stamp Tool: copies texture from a user-defined source pin to target brush points
function applyCloneStamp(
  ctx: CanvasRenderingContext2D,
  points: { x: number; y: number }[],
  radius: number,
  opacity: number,
  sourcePoint: { x: number; y: number } | undefined,
  canvasWidth: number,
  canvasHeight: number
) {
  if (!sourcePoint || points.length === 0) return;

  const firstPt = points[0];
  const deltaX = sourcePoint.x - firstPt.x;
  const deltaY = sourcePoint.y - firstPt.y;

  for (const pt of points) {
    const srcX = pt.x + deltaX;
    const srcY = pt.y + deltaY;

    const minSrcX = Math.max(0, Math.floor(srcX - radius));
    const minSrcY = Math.max(0, Math.floor(srcY - radius));
    const maxSrcX = Math.min(canvasWidth - 1, Math.ceil(srcX + radius));
    const maxSrcY = Math.min(canvasHeight - 1, Math.ceil(srcY + radius));
    const srcW = maxSrcX - minSrcX;
    const srcH = maxSrcY - minSrcY;

    if (srcW <= 0 || srcH <= 0) continue;

    const srcData = ctx.getImageData(minSrcX, minSrcY, srcW, srcH).data;

    const minDstX = Math.max(0, Math.floor(pt.x - radius));
    const minDstY = Math.max(0, Math.floor(pt.y - radius));
    const maxDstX = Math.min(canvasWidth - 1, Math.ceil(pt.x + radius));
    const maxDstY = Math.min(canvasHeight - 1, Math.ceil(pt.y + radius));
    const dstW = maxDstX - minDstX;
    const dstH = maxDstY - minDstY;

    if (dstW <= 0 || dstH <= 0) continue;

    const dstImg = ctx.getImageData(minDstX, minDstY, dstW, dstH);
    const dstData = dstImg.data;

    for (let y = 0; y < dstH; y++) {
      for (let x = 0; x < dstW; x++) {
        const px = minDstX + x;
        const py = minDstY + y;
        const dist = Math.hypot(px - pt.x, py - pt.y);

        if (dist <= radius) {
          const falloff = Math.cos((dist / radius) * (Math.PI / 2)) * opacity;
          const dIdx = (y * dstW + x) * 4;

          const sx = Math.min(srcW - 1, Math.max(0, Math.floor(x * (srcW / dstW))));
          const sy = Math.min(srcH - 1, Math.max(0, Math.floor(y * (srcH / dstH))));
          const sIdx = (sy * srcW + sx) * 4;

          dstData[dIdx] = clamp(dstData[dIdx] * (1 - falloff) + srcData[sIdx] * falloff);
          dstData[dIdx + 1] = clamp(dstData[dIdx + 1] * (1 - falloff) + srcData[sIdx + 1] * falloff);
          dstData[dIdx + 2] = clamp(dstData[dIdx + 2] * (1 - falloff) + srcData[sIdx + 2] * falloff);
        }
      }
    }

    ctx.putImageData(dstImg, minDstX, minDstY);
  }
}

// 8. Red-Eye Fixer: neutralizes flash pupil glare
function applyRedEyeFix(
  ctx: CanvasRenderingContext2D,
  points: { x: number; y: number }[],
  radius: number,
  opacity: number,
  canvasWidth: number,
  canvasHeight: number
) {
  for (const pt of points) {
    const minX = Math.max(0, Math.floor(pt.x - radius));
    const minY = Math.max(0, Math.floor(pt.y - radius));
    const maxX = Math.min(canvasWidth - 1, Math.ceil(pt.x + radius));
    const maxY = Math.min(canvasHeight - 1, Math.ceil(pt.y + radius));
    const patchW = maxX - minX;
    const patchH = maxY - minY;

    if (patchW <= 0 || patchH <= 0) continue;

    const imgData = ctx.getImageData(minX, minY, patchW, patchH);
    const data = imgData.data;

    for (let y = 0; y < patchH; y++) {
      for (let x = 0; x < patchW; x++) {
        const px = minX + x;
        const py = minY + y;
        const dist = Math.hypot(px - pt.x, py - pt.y);

        if (dist <= radius) {
          const idx = (y * patchW + x) * 4;
          const r = data[idx];
          const g = data[idx + 1];
          const b = data[idx + 2];

          // Check if pixel is predominantly red flash artifact (r > 1.35 * max(g,b))
          const otherMax = Math.max(g, b);
          if (r > 60 && r > otherMax * 1.3) {
            const falloff = Math.cos((dist / radius) * (Math.PI / 2)) * opacity;
            // Target pupil tone: dark neutral matching surrounding green/blue luminance
            const neutralDark = Math.min(40, (g + b) / 2);

            data[idx] = clamp(r * (1 - falloff) + neutralDark * falloff);
            data[idx + 1] = clamp(g * (1 - falloff) + neutralDark * falloff);
            data[idx + 2] = clamp(b * (1 - falloff) + neutralDark * falloff);
          }
        }
      }
    }

    ctx.putImageData(imgData, minX, minY);
  }
}

// 9. Color Splash: saturates target strokes to vibrant color
function applyColorSplash(
  ctx: CanvasRenderingContext2D,
  points: { x: number; y: number }[],
  radius: number,
  opacity: number,
  canvasWidth: number,
  canvasHeight: number
) {
  for (const pt of points) {
    const minX = Math.max(0, Math.floor(pt.x - radius));
    const minY = Math.max(0, Math.floor(pt.y - radius));
    const maxX = Math.min(canvasWidth - 1, Math.ceil(pt.x + radius));
    const maxY = Math.min(canvasHeight - 1, Math.ceil(pt.y + radius));
    const patchW = maxX - minX;
    const patchH = maxY - minY;

    if (patchW <= 0 || patchH <= 0) continue;

    const imgData = ctx.getImageData(minX, minY, patchW, patchH);
    const data = imgData.data;

    for (let y = 0; y < patchH; y++) {
      for (let x = 0; x < patchW; x++) {
        const px = minX + x;
        const py = minY + y;
        const dist = Math.hypot(px - pt.x, py - pt.y);

        if (dist <= radius) {
          const idx = (y * patchW + x) * 4;
          const falloff = Math.cos((dist / radius) * (Math.PI / 2)) * opacity;

          const [h, s, l] = rgbToHsl(data[idx], data[idx + 1], data[idx + 2]);
          const newS = Math.min(1, s + 0.35 * falloff);
          const [nr, ng, nb] = hslToRgb(h, newS, l);

          data[idx] = nr;
          data[idx + 1] = ng;
          data[idx + 2] = nb;
        }
      }
    }

    ctx.putImageData(imgData, minX, minY);
  }
}

