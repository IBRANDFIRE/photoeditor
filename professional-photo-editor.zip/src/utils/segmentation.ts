import { clamp } from "./imageProcessing";

// Build a full-resolution alpha mask canvas from polygon or saliency
export function createMaskFromPolygon(
  width: number,
  height: number,
  polygon: { x: number; y: number }[],
  boxes?: { ymin: number; xmin: number; ymax: number; xmax: number }[]
): HTMLCanvasElement {
  const maskCanvas = document.createElement("canvas");
  maskCanvas.width = width;
  maskCanvas.height = height;
  const ctx = maskCanvas.getContext("2d");
  if (!ctx) return maskCanvas;

  // Clear to black (transparent / background)
  ctx.fillStyle = "black";
  ctx.fillRect(0, 0, width, height);

  ctx.fillStyle = "white";

  // If bounding boxes exist, add rounded rects
  if (boxes && boxes.length > 0) {
    for (const b of boxes) {
      const bx = b.xmin * width;
      const by = b.ymin * height;
      const bw = (b.xmax - b.xmin) * width;
      const bh = (b.ymax - b.ymin) * height;

      ctx.beginPath();
      // Draw rounded rect
      const radius = Math.min(bw, bh) * 0.15;
      ctx.roundRect ? ctx.roundRect(bx, by, bw, bh, radius) : ctx.rect(bx, by, bw, bh);
      ctx.fill();
    }
  }

  // Draw smooth polygon contour
  if (polygon && polygon.length >= 3) {
    ctx.beginPath();
    ctx.moveTo(polygon[0].x * width, polygon[0].y * height);
    for (let i = 1; i < polygon.length; i++) {
      ctx.lineTo(polygon[i].x * width, polygon[i].y * height);
    }
    ctx.closePath();
    ctx.fill();
  }

  // Apply subtle bilateral / feathering blur to mask edges for natural hair and edge roll-off
  const tempCanvas = document.createElement("canvas");
  tempCanvas.width = width;
  tempCanvas.height = height;
  const tempCtx = tempCanvas.getContext("2d");
  if (tempCtx) {
    tempCtx.filter = "blur(4px)";
    tempCtx.drawImage(maskCanvas, 0, 0);
    ctx.clearRect(0, 0, width, height);
    ctx.drawImage(tempCanvas, 0, 0);
  }

  return maskCanvas;
}

// Client-side fallback saliency segmentation (works offline / instant preview)
export function generateLocalSaliencyMask(
  sourceCanvas: HTMLCanvasElement
): HTMLCanvasElement {
  const width = sourceCanvas.width;
  const height = sourceCanvas.height;

  const maskCanvas = document.createElement("canvas");
  maskCanvas.width = width;
  maskCanvas.height = height;
  const maskCtx = maskCanvas.getContext("2d");
  if (!maskCtx) return maskCanvas;

  const srcCtx = sourceCanvas.getContext("2d", { willReadFrequently: true });
  if (!srcCtx) return maskCanvas;

  const srcData = srcCtx.getImageData(0, 0, width, height).data;
  const maskImgData = maskCtx.createImageData(width, height);
  const maskData = maskImgData.data;

  // Center prior coordinates (subjects are mostly centered in professional photography)
  const cx = width / 2;
  const cy = height * 0.48;
  const sigmaX = width * 0.35;
  const sigmaY = height * 0.42;

  // Compute 4-corner ambient background color
  const sampleCorner = (x: number, y: number) => {
    const idx = (y * width + x) * 4;
    return [srcData[idx], srcData[idx + 1], srcData[idx + 2]];
  };

  const c1 = sampleCorner(4, 4);
  const c2 = sampleCorner(width - 5, 4);
  const c3 = sampleCorner(4, height - 5);
  const c4 = sampleCorner(width - 5, height - 5);

  const bgR = (c1[0] + c2[0] + c3[0] + c4[0]) / 4;
  const bgG = (c1[1] + c2[1] + c3[1] + c4[1]) / 4;
  const bgB = (c1[2] + c2[2] + c3[2] + c4[2]) / 4;

  for (let y = 0; y < height; y++) {
    for (let x = 0; x < width; x++) {
      const idx = (y * width + x) * 4;

      const r = srcData[idx];
      const g = srcData[idx + 1];
      const b = srcData[idx + 2];

      // Distance from corner background color
      const colorDist = Math.hypot(r - bgR, g - bgG, b - bgB) / 441.67; // 0..1

      // Spatial Gaussian center prior
      const dx = (x - cx) / sigmaX;
      const dy = (y - cy) / sigmaY;
      const spatialPrior = Math.exp(-0.5 * (dx * dx + dy * dy));

      // Subject saliency score
      const saliency = Math.min(1, Math.max(0, colorDist * 0.6 + spatialPrior * 0.5));
      const alpha = Math.round(Math.pow(saliency, 1.4) * 255);

      maskData[idx] = 255;
      maskData[idx + 1] = 255;
      maskData[idx + 2] = 255;
      maskData[idx + 3] = alpha;
    }
  }

  maskCtx.putImageData(maskImgData, 0, 0);

  // Smooth mask boundaries with Gaussian blur
  const blurCanvas = document.createElement("canvas");
  blurCanvas.width = width;
  blurCanvas.height = height;
  const blurCtx = blurCanvas.getContext("2d");
  if (blurCtx) {
    blurCtx.filter = "blur(6px)";
    blurCtx.drawImage(maskCanvas, 0, 0);
    maskCtx.clearRect(0, 0, width, height);
    maskCtx.drawImage(blurCanvas, 0, 0);
  }

  return maskCanvas;
}

// Render background replacement (transparent cutout, solid studio backdrops, or bokeh blur)
export function renderBackgroundReplacement(
  sourceCanvas: HTMLCanvasElement,
  maskCanvas: HTMLCanvasElement,
  destCanvas: HTMLCanvasElement,
  mode: "transparent" | "blur" | "solid",
  solidColor = "#ffffff",
  blurRadius = 16
) {
  const width = sourceCanvas.width;
  const height = sourceCanvas.height;

  destCanvas.width = width;
  destCanvas.height = height;
  const ctx = destCanvas.getContext("2d");
  if (!ctx) return;

  ctx.clearRect(0, 0, width, height);

  if (mode === "transparent") {
    // Subject only, background is transparent
    ctx.drawImage(sourceCanvas, 0, 0);
    ctx.globalCompositeOperation = "destination-in";
    ctx.drawImage(maskCanvas, 0, 0);
    ctx.globalCompositeOperation = "source-over";
    return;
  }

  if (mode === "solid") {
    // Fill with solid backdrop color
    ctx.fillStyle = solidColor;
    ctx.fillRect(0, 0, width, height);

    // Draw cutout subject over solid color
    const subjectCanvas = document.createElement("canvas");
    subjectCanvas.width = width;
    subjectCanvas.height = height;
    const subCtx = subjectCanvas.getContext("2d");
    if (subCtx) {
      subCtx.drawImage(sourceCanvas, 0, 0);
      subCtx.globalCompositeOperation = "destination-in";
      subCtx.drawImage(maskCanvas, 0, 0);
      ctx.drawImage(subjectCanvas, 0, 0);
    }
    return;
  }

  if (mode === "blur") {
    // Render blurred background
    const bgCanvas = document.createElement("canvas");
    bgCanvas.width = width;
    bgCanvas.height = height;
    const bgCtx = bgCanvas.getContext("2d");
    if (bgCtx) {
      bgCtx.filter = `blur(${Math.max(2, blurRadius)}px)`;
      bgCtx.drawImage(sourceCanvas, 0, 0);
    }
    ctx.drawImage(bgCanvas, 0, 0);

    // Overlay crisp subject
    const subjectCanvas = document.createElement("canvas");
    subjectCanvas.width = width;
    subjectCanvas.height = height;
    const subCtx = subjectCanvas.getContext("2d");
    if (subCtx) {
      subCtx.drawImage(sourceCanvas, 0, 0);
      subCtx.globalCompositeOperation = "destination-in";
      subCtx.drawImage(maskCanvas, 0, 0);
      ctx.drawImage(subjectCanvas, 0, 0);
    }
  }
}
